//
//  ViewController.h
//  AckermanMenkhaus-BasketGame
//
//  Created by Chad Ackerman on 4/2/14.
//  Copyright (c) 2014 UC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *btnFourPlayer;
@property (weak, nonatomic) IBOutlet UIButton *btnSixPlayer;
@property (weak, nonatomic) IBOutlet UIButton *btnShare;

@end
